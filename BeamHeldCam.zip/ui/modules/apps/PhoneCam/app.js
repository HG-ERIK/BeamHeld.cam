angular.module('beamng.apps')
.directive('phoneCam', [function () {
  return {
    template:
      '<div class="pcs">' +
      '<style>' +
      '.pcs{font-family:"Segoe UI",Arial,sans-serif;font-size:12px;color:#fff;' +
      'background:#000;padding:10px;height:100%;box-sizing:border-box;' +
      'border:1px solid #2E2E2E;}' +
      '.pcs-head{display:flex;justify-content:space-between;align-items:center;' +
      'padding-bottom:8px;border-bottom:2px solid #E32227;}' +
      '.pcs-name{font-size:14px;font-weight:700;letter-spacing:0.5px;}' +
      '.pcs-name i{color:#FF6800;font-style:italic;}' +
      '.pcs-pill{font-size:10px;font-weight:700;letter-spacing:1px;padding:3px 9px;' +
      'border:1px solid #E32227;color:#E32227;background:#150000;}' +
      '.pcs-pill.on{border-color:#FF6800;color:#000;background:#FF6800;}' +
      '.pcs-main{width:100%;margin-top:10px;padding:11px 0;font-size:13px;' +
      'font-weight:700;letter-spacing:1px;cursor:pointer;color:#fff;' +
      'background:#141414;border:1px solid #3A3A3A;}' +
      '.pcs-main:hover{background:#1E1E1E;}' +
      '.pcs-main.on{background:#FF6800;border-color:#FF6800;color:#000;}' +
      '.pcs-main.on:hover{background:#FF7D22;}' +
      '.pcs-box{margin-top:10px;background:#0D0D0D;border:1px solid #2E2E2E;padding:8px 10px;}' +
      '.pcs-chk{display:flex;align-items:center;cursor:pointer;padding:5px 0;}' +
      '.pcs-chk+.pcs-chk{border-top:1px solid #1E1E1E;}' +
      '.pcs-tick{width:15px;height:15px;flex:0 0 15px;margin-right:9px;' +
      'border:1px solid #4A4A4A;background:#000;color:#fff;font-size:11px;' +
      'font-weight:700;line-height:15px;text-align:center;}' +
      '.pcs-tick.on{background:#FF6800;border-color:#FF6800;color:#000;}' +
      '.pcs-chk-txt{flex:1;}' +
      '.pcs-chk-sub{color:#8C8C8C;font-size:10px;}' +
      '.pcs-foot{display:flex;justify-content:space-between;align-items:baseline;' +
      'margin-top:10px;padding-top:7px;border-top:1px solid #2E2E2E;}' +
      '.pcs-zoom{font-size:17px;font-weight:700;color:#fff;}' +
      '.pcs-zoom span{font-size:10px;color:#8C8C8C;font-weight:400;}' +
      '.pcs-trk{font-size:10px;font-weight:700;letter-spacing:1px;color:#E32227;}' +
      '.pcs-trk.ok{color:#FF6800;}' +
      '.pcs-credit{margin-top:6px;text-align:right;font-size:9px;color:#5A5A5A;' +
      'letter-spacing:1px;}' +
      '</style>' +

      '<div class="pcs-head">' +
      '<div class="pcs-name">BeamHeld<i>.cam</i></div>' +
      '<div class="pcs-pill" ng-class="{on: state.enabled}">' +
      '{{ state.enabled ? \'ON\' : \'OFF\' }}</div>' +
      '</div>' +

      '<div class="pcs-main" ng-class="{on: state.enabled}" ng-click="toggle()">' +
      '{{ state.enabled ? \'DISABLE\' : \'ENABLE\' }}</div>' +

      '<div class="pcs-box">' +

      '<div class="pcs-chk" ng-click="setSmooth(!isSmooth())">' +
      '<div class="pcs-tick" ng-class="{on: isSmooth()}">{{ isSmooth() ? \'&#10003;\' : \'\' }}</div>' +
      '<div class="pcs-chk-txt">Smoothing' +
      '<div class="pcs-chk-sub">30Hz phone feed smoothing</div></div>' +
      '</div>' +

      '<div class="pcs-chk" ng-click="setShake(!isShake())">' +
      '<div class="pcs-tick" ng-class="{on: isShake()}">{{ isShake() ? \'&#10003;\' : \'\' }}</div>' +
      '<div class="pcs-chk-txt">Handheld feel' +
      '<div class="pcs-chk-sub">with this enabled the g forces also apply to the virtual cam</div></div>' +
      '</div>' +

      '<div class="pcs-chk" ng-click="setLod(!isLod())">' +
      '<div class="pcs-tick" ng-class="{on: isLod()}">{{ isLod() ? \'&#10003;\' : \'\' }}</div>' +
      '<div class="pcs-chk-txt">Zoom performance' +
      '<div class="pcs-chk-sub">Does it lag when you zoom? try to enable this</div></div>' +
      '</div>' +

      '</div>' +

      '<div class="pcs-foot">' +
      '<div class="pcs-zoom">{{ state.zoomFactor | number:2 }}<span>x</span></div>' +
      '<div class="pcs-trk" ng-class="{ok: state.tracking}">' +
      '{{ state.tracking ? \'TRACKING\' : \'NO SIGNAL\' }}</div>' +
      '</div>' +

      '<div class="pcs-credit">made by HG-ERIK</div>' +

      '</div>',
    replace: true,
    restrict: 'EA',
    link: function (scope, element, attrs) {

      // Fixed values; the HUD only switches these on and off.
      var SMOOTH_ON = 0.3;
      var SHAKE_ON = 2.0;
      var LOD_ON = 0.5;

      scope.state = {
        enabled: false,
        tracking: false,
        smoothing: 0.3,
        zoomFactor: 1.0,
        zoomLodComp: 0.5,
        shakeCompliance: 2.0
      };

      scope.$on('PhoneCamState', function (event, data) {
        if (data) { scope.state = data; }
      });

      scope.isSmooth = function () {
        return scope.state.smoothing > 0.001;
      };

      scope.toggle = function () {
        bngApi.engineLua('extensions.auto_phoneCam.toggle()');
      };
      scope.setSmooth = function (on) {
        bngApi.engineLua('extensions.auto_phoneCam.setSmoothing(' +
          (on ? SMOOTH_ON : 0) + ')');
      };
      scope.isShake = function () {
        return scope.state.shakeCompliance > 0.001;
      };
      scope.setShake = function (on) {
        bngApi.engineLua('extensions.auto_phoneCam.setShakeCompliance(' +
          (on ? SHAKE_ON : 0) + ')');
      };
      scope.isLod = function () {
        return scope.state.zoomLodComp > 0.001;
      };
      scope.setLod = function (on) {
        bngApi.engineLua('extensions.auto_phoneCam.setZoomLodComp(' +
          (on ? LOD_ON : 0) + ')');
      };
    }
  };
}]);
