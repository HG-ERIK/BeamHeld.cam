angular.module('beamng.apps')
.directive('phoneCamAdvanced', [function () {
  return {
    template:
      '<div class="pca">' +
      '<style>' +
      '.pca{font-family:"Segoe UI",Arial,sans-serif;font-size:12px;color:#fff;' +
      'background:#000;padding:10px;height:100%;box-sizing:border-box;' +
      'border:1px solid #2E2E2E;overflow-y:auto;}' +
      '.pca-head{display:flex;justify-content:space-between;align-items:center;' +
      'padding-bottom:8px;border-bottom:2px solid #E32227;}' +
      '.pca-name{font-size:14px;font-weight:700;letter-spacing:0.5px;}' +
      '.pca-name i{color:#FF6800;font-style:italic;}' +
      '.pca-name b{font-weight:400;font-size:9px;color:#8C8C8C;letter-spacing:1px;}' +
      '.pca-pill{font-size:10px;font-weight:700;letter-spacing:1px;padding:3px 9px;' +
      'border:1px solid #E32227;color:#E32227;background:#150000;}' +
      '.pca-pill.on{border-color:#FF6800;color:#000;background:#FF6800;}' +
      '.pca-sec{margin-top:11px;}' +
      '.pca-lbl{font-size:10px;font-weight:700;letter-spacing:1.4px;color:#E32227;' +
      'margin-bottom:5px;}' +
      '.pca-row{display:flex;align-items:center;gap:5px;margin-bottom:5px;}' +
      '.pca-btn{flex:1;padding:6px 4px;text-align:center;cursor:pointer;color:#fff;' +
      'background:#141414;border:1px solid #3A3A3A;font-size:11px;}' +
      '.pca-btn:hover{background:#1E1E1E;}' +
      '.pca-btn.on{background:#FF6800;border-color:#FF6800;color:#000;font-weight:700;}' +
      '.pca-btn.sign{flex:0 0 40px;font-weight:700;}' +
      '.pca-btn.wide{font-weight:700;letter-spacing:1px;}' +
      '.pca-ax{flex:0 0 14px;font-weight:700;color:#8C8C8C;}' +
      '.pca-chk{display:flex;align-items:center;cursor:pointer;padding:5px 0;}' +
      '.pca-tick{width:15px;height:15px;flex:0 0 15px;margin-right:9px;' +
      'border:1px solid #4A4A4A;background:#000;color:#fff;font-size:11px;' +
      'font-weight:700;line-height:15px;text-align:center;}' +
      '.pca-tick.on{background:#FF6800;border-color:#FF6800;color:#000;}' +
      '.pca-sub{color:#8C8C8C;font-size:10px;}' +
      '.pca-slider{flex:1;}' +
      '.pca-port{flex:1;background:#000;border:1px solid #4A4A4A;color:#fff;' +
      'font-family:monospace;font-size:13px;padding:5px 8px;}' +
      '.pca-val{flex:0 0 34px;text-align:right;font-family:monospace;color:#fff;}' +
      '.pca-tele{margin-top:11px;padding-top:7px;border-top:1px solid #2E2E2E;' +
      'font-family:monospace;font-size:10px;color:#8C8C8C;line-height:1.6;}' +
      '.pca-tele b{color:#fff;font-weight:400;}' +
      '.pca-trk{font-weight:700;letter-spacing:1px;color:#E32227;}' +
      '.pca-trk.ok{color:#FF6800;}' +
      '.pca-warn{color:#E32227;font-weight:700;}' +
      '.pca-wiz{margin-top:11px;background:#150000;border:1px solid #E32227;padding:10px;}' +
      '.pca-wiz-step{font-size:10px;letter-spacing:1.4px;color:#E32227;font-weight:700;}' +
      '.pca-wiz-prompt{font-size:15px;font-weight:700;margin-top:5px;line-height:1.25;}' +
      '.pca-wiz-hint{font-size:10px;color:#8C8C8C;margin-top:3px;}' +
      '.pca-wiz-state{margin-top:8px;font-size:11px;font-weight:700;color:#FF6800;' +
      'letter-spacing:1px;}' +
      '.pca-wiz-state.wait{color:#8C8C8C;}' +
      '.pca-err{margin-top:6px;font-size:10px;color:#E32227;line-height:1.4;}' +
      '.pca-credit{margin-top:6px;text-align:right;font-size:9px;color:#5A5A5A;' +
      'letter-spacing:1px;}' +
      '</style>' +

      '<div class="pca-head">' +
      '<div class="pca-name">BeamHeld<i>.cam</i> <b>ADVANCED</b></div>' +
      '<div class="pca-pill" ng-class="{on: state.enabled}">' +
      '{{ state.enabled ? \'ON\' : \'OFF\' }}</div>' +
      '</div>' +

      '<div class="pca-sec">' +
      '<div class="pca-row">' +
      '<div class="pca-btn wide" ng-class="{on: state.enabled}" ng-click="toggle()">' +
      '{{ state.enabled ? \'DISABLE\' : \'ENABLE\' }}</div>' +
      '<div class="pca-btn wide" ng-click="recenter()">RECENTER</div>' +
      '</div>' +
      '</div>' +

      '<div class="pca-wiz" ng-if="state.wizard.active">' +
      '<div class="pca-wiz-step">MAPPING WIZARD &nbsp;&#183;&nbsp; STEP {{ state.wizard.step }} / {{ state.wizard.total }}</div>' +
      '<div class="pca-wiz-prompt">{{ state.wizard.prompt }}</div>' +
      '<div class="pca-wiz-hint">{{ state.wizard.hint }}</div>' +
      '<div class="pca-wiz-state" ng-class="{wait: state.wizard.phase !== \'armed\'}">' +
      '{{ state.wizard.phase === \'armed\' ? ' +
      '(state.wizard.kind === \'pos\' ? \'MOVE IT NOW\' : \'ROTATE IT NOW\') : ' +
      '\'GOT IT - hold still\' }}' +
      '<span ng-if="state.wizard.detected"> &nbsp;&#183;&nbsp; {{ state.wizard.detected }}</span>' +
      '</div>' +
      '<div class="pca-row" style="margin-top:9px;">' +
      '<div class="pca-btn wide" ng-click="wizCancel()">CANCEL</div>' +
      '</div>' +
      '</div>' +

      '<div class="pca-sec">' +
      '<div class="pca-lbl">UDP PORT</div>' +
      '<div class="pca-row">' +
      '<input class="pca-port" type="number" min="1024" max="65535" ' +
      'ng-model="portEdit">' +
      '<div class="pca-btn sign" style="flex:0 0 62px;" ng-click="applyPort()">SET</div>' +
      '</div>' +
      '<div class="pca-sub">must match the port in the phone app. only change ' +
      'it if the two cannot find each other. currently listening on ' +
      '{{ state.port }}.</div>' +
      '</div>' +

      '<div class="pca-sec">' +
      '<div class="pca-lbl">ZOOM LOD COMPENSATION</div>' +
      '<div class="pca-row">' +
      '<input class="pca-slider" type="range" min="0" max="1" step="0.05" ' +
      'ng-model="state.zoomLodComp" ng-change="setLod(state.zoomLodComp)">' +
      '<div class="pca-val">{{ state.zoomLodComp | number:2 }}</div>' +
      '</div>' +
      '<div class="pca-sub">{{ lodLabel() }}</div>' +
      '</div>' +

      '<div class="pca-sec">' +
      '<div class="pca-lbl">AXIS MAPPING (ROTATION)</div>' +
      '<div class="pca-row" ng-repeat="k in [\'x\',\'y\',\'z\']">' +
      '<div class="pca-ax">{{ k.toUpperCase() }}</div>' +
      '<div class="pca-btn" ng-click="cycleSource(k)">{{ state.map[k].srcName }}</div>' +
      '<div class="pca-btn sign" ng-click="flipSign(k)">' +
      '{{ state.map[k].sign > 0 ? \'+\' : \'&#8722;\' }}</div>' +
      '</div>' +
      '<div class="pca-sub pca-warn" ng-if="!state.valid">' +
      'invalid map - each phone axis must be used once</div>' +
      '<div class="pca-row" ng-if="!state.wizard.active">' +
      '<div class="pca-btn wide" ng-click="wizStart()">CALIBRATE BY MOVING THE PHONE</div>' +
      '</div>' +
      '<div class="pca-err" ng-if="state.wizard.err">{{ state.wizard.err }}</div>' +
      '</div>' +

      '<div class="pca-sec">' +
      '<div class="pca-lbl">POSITION INVERT (6-DOF)</div>' +
      '<div class="pca-row">' +
      '<div class="pca-btn" ng-class="{on: state.posInvert.x}" ng-click="flipPosInvert(\'x\')">' +
      'X {{ state.posInvert.x ? \'INV\' : \'NORM\' }}</div>' +
      '<div class="pca-btn" ng-class="{on: state.posInvert.y}" ng-click="flipPosInvert(\'y\')">' +
      'Y {{ state.posInvert.y ? \'INV\' : \'NORM\' }}</div>' +
      '<div class="pca-btn" ng-class="{on: state.posInvert.z}" ng-click="flipPosInvert(\'z\')">' +
      'Z {{ state.posInvert.z ? \'INV\' : \'NORM\' }}</div>' +
      '</div>' +
      '</div>' +

      '<div class="pca-sec">' +
      '<div class="pca-row">' +
      '<div class="pca-btn wide" ng-click="save()">SAVE</div>' +
      '<div class="pca-btn wide" ng-click="reset()">DEFAULTS</div>' +
      '</div>' +
      '</div>' +

      '<div class="pca-tele">' +
      '<div>state &nbsp;<span class="pca-trk" ng-class="{ok: state.tracking}">' +
      '{{ state.tracking ? \'TRACKING\' : \'NO SIGNAL\' }}</span>' +
      ' &nbsp;pkts <b>{{ state.packets }}</b></div>' +
      '<div>zoom &nbsp;<b>{{ state.zoomFactor | number:2 }}x</b>' +
      ' &nbsp;range <b>{{ state.zoomMin | number:1 }}-{{ state.zoomMax | number:1 }}x</b></div>' +
      '<div>quat &nbsp;<b>{{ state.raw.x | number:2 }} {{ state.raw.y | number:2 }} ' +
      '{{ state.raw.z | number:2 }} {{ state.raw.w | number:2 }}</b></div>' +
      '<div>pos &nbsp;&nbsp;<b>{{ state.pos.x | number:2 }} {{ state.pos.y | number:2 }} ' +
      '{{ state.pos.z | number:2 }}</b></div>' +
      '</div>' +

      '<div class="pca-credit">made by HG-ERIK</div>' +

      '</div>',
    replace: true,
    restrict: 'EA',
    link: function (scope, element, attrs) {

      scope.state = {
        enabled: false,
        valid: true,
        tracking: false,
        packets: 0,
        raw: { x: 0, y: 0, z: 0, w: 1 },
        pos: { x: 0, y: 0, z: 0 },
        posInvert: { x: true, y: true, z: true },
        smoothing: 0.3,
        zoomFactor: 1.0,
        zoomMin: 0.7,
        zoomMax: 8.0,
        zoomLodComp: 0.5,
        shakeCompliance: 2.0,
        port: 47821,
        map: {
          x: { srcName: 'Phone X', sign: -1 },
          y: { srcName: 'Phone Z', sign: 1 },
          z: { srcName: 'Phone Y', sign: -1 }
        },
        wizard: {
          active: false, step: 0, total: 6, phase: 'idle',
          prompt: '', hint: '', kind: '', detected: ''
        }
      };

      // Separate from scope.state on purpose: state is replaced wholesale ten
      // times a second, which would fight the user mid-keystroke. Seeded once,
      // then only the SET button pushes it back.
      scope.portEdit = null;

      scope.$on('PhoneCamState', function (event, data) {
        if (data) {
          scope.state = data;
          if (scope.portEdit === null && data.port) {
            scope.portEdit = data.port;
          }
        }
      });

      scope.applyPort = function () {
        var p = parseInt(scope.portEdit, 10);
        if (!p || p < 1024 || p > 65535) { return; }
        bngApi.engineLua('extensions.auto_phoneCam.setPort(' + p + ')');
      };

      scope.toggle = function () {
        bngApi.engineLua('extensions.auto_phoneCam.toggle()');
      };
      scope.recenter = function () {
        bngApi.engineLua('extensions.auto_phoneCam.recenter()');
      };
      scope.cycleSource = function (k) {
        bngApi.engineLua("extensions.auto_phoneCam.cycleSource('" + k + "')");
      };
      scope.flipSign = function (k) {
        bngApi.engineLua("extensions.auto_phoneCam.flipSign('" + k + "')");
      };
      scope.flipPosInvert = function (k) {
        bngApi.engineLua("extensions.auto_phoneCam.flipPosInvert('" + k + "')");
      };
      scope.setLod = function (val) {
        bngApi.engineLua('extensions.auto_phoneCam.setZoomLodComp(' + val + ')');
      };
      // Kept in JS rather than an inline expression: comparison operators in
      // an interpolated attribute string are asking for HTML-parser trouble.
      scope.lodLabel = function () {
        var v = scope.state.zoomLodComp;
        if (v <= 0.001) return 'off';
        if (v >= 0.999) return 'max fps, blurry at high zoom';
        return 'higher = more fps, less detail when zoomed';
      };
      scope.save = function () {
        bngApi.engineLua('extensions.auto_phoneCam.saveCalibration()');
      };
      scope.reset = function () {
        bngApi.engineLua('extensions.auto_phoneCam.resetCalibration()');
      };
      scope.wizStart = function () {
        bngApi.engineLua('extensions.auto_phoneCam.wizardStart()');
      };
      scope.wizCancel = function () {
        bngApi.engineLua('extensions.auto_phoneCam.wizardCancel()');
      };
    }
  };
}]);
