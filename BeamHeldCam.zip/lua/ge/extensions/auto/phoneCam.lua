-- Save as: lua/ge/extensions/auto/phoneCam.lua

local M = {}

local socket = require("socket")
local udpSocket = nil
local PORT = 47821

local CONFIG_PATH = "settings/phoneCamCalibration.json"
local CONFIG_VERSION = 3   -- bumped when the defaults below changed

local isEnabled = false

-- Newest values received from the phone (~30Hz)
local targetRot = quat(0, 0, 0, 1)
local targetPos = vec3(0, 0, 0)

-- Smoothed values actually used for rendering (updated every frame, ~75Hz)
local phoneRot = quat(0, 0, 0, 1)
local phonePos = vec3(0, 0, 0)

local zeroRot  = quat(0, 0, 0, 1)
local zeroPos  = vec3(0, 0, 0)
local tracking = false

-- Unmapped values straight off the wire. The mapping wizard has to reason
-- about what the PHONE did, so it cannot use the already-remapped values.
local rawQuat = { x = 0, y = 0, z = 0, w = 1 }
local rawPos  = { x = 0, y = 0, z = 0 }

local zoomFactor = 1.0     -- 1.0 = car's own FOV, 2.0 = 2x tele, 0.7 = wide
local zoomRate = 0         -- -1..+1 from the rocker
local baseFov = nil
local pendingRecenter = false

-- modeName -> { C = metatable, original = the update() we replaced }
local patchedModes = {}

local packetsReceived = 0
local loggedFirstPacket = false

-- HEARTBEAT: UDP is fire-and-forget, so the phone cannot otherwise tell
-- whether anything is listening. We reply to whatever address last sent us a
-- packet; the phone treats silence as "no PC connected".
local phoneIp = nil
local phonePort = nil
local ackTimer = 0
local ACK_INTERVAL = 0.5

local CFG = {
    -- SMOOTHING: the phone sends ~30Hz but the game renders ~75Hz, so without
    -- this each pose is held for ~2.5 frames. Fixed at 0.3; the HUD only
    -- switches it on and off.
    smoothing = 0.3,
    posInvert = { x = true, y = true, z = true },
    zoomEnabled = true,
    zoomRateSpeed = 1.6,   -- how fast the rocker zooms at full deflection
    zoomMin = 0.7,
    zoomMax = 8.0,
    -- ZOOM LOD COMPENSATION, 0 = off, 1 = full. See the block further down.
    zoomLodComp = 0.5,
    -- HANDHELD FEEL. Fixed at 2.0; the HUD only switches it on and off.
    shakeCompliance = 2.0,
}

local function clamp(v, lo, hi)
    if v < lo then return lo end
    if v > hi then return hi end
    return v
end

-- ============================================================
-- AXIS REMAP
-- ============================================================

-- Defaults are the mapping that was calibrated by hand and confirmed working:
-- X = Phone X (-),  Y = Phone Z (+),  Z = Phone Y (-)
local function defaultAxisMap()
    return {
        x = { src = 1, sign = -1 },
        y = { src = 3, sign =  1 },
        z = { src = 2, sign = -1 },
    }
end

local axisMap = defaultAxisMap()

local axisNames = {"Phone X", "Phone Y", "Phone Z"}

local function computeDeterminant(map)
    local m = {}
    for i = 1, 3 do m[i] = {0, 0, 0} end
    local keys = {"x", "y", "z"}
    for row, k in ipairs(keys) do
        local e = map[k]
        if not e or e.src < 1 or e.src > 3 then return nil end
        m[row][e.src] = e.sign
    end
    local det =
        m[1][1] * (m[2][2] * m[3][3] - m[2][3] * m[3][2]) -
        m[1][2] * (m[2][1] * m[3][3] - m[2][3] * m[3][1]) +
        m[1][3] * (m[2][1] * m[3][2] - m[2][2] * m[3][1])
    return det
end

local function isMapValid(map)
    local used = {[1] = 0, [2] = 0, [3] = 0}
    for _, k in ipairs({"x", "y", "z"}) do
        local e = map[k]
        if not e then return false end
        used[e.src] = (used[e.src] or 0) + 1
    end
    if used[1] ~= 1 or used[2] ~= 1 or used[3] ~= 1 then return false end
    -- abs(): ARCore is Y-up and BeamNG is Z-up, so the working mapping is a
    -- handedness-flipping permutation (det = -1). Only a repeated or missing
    -- source axis is actually invalid.
    local det = computeDeterminant(map)
    return det ~= nil and math.abs(det) == 1
end

local function remapQuat(rx, ry, rz, rw, map)
    local src = {rx, ry, rz}
    local nx = src[map.x.src] * map.x.sign
    local ny = src[map.y.src] * map.y.sign
    local nz = src[map.z.src] * map.z.sign
    return quat(nx, ny, nz, rw)
end

local function remapVec3(rx, ry, rz, map)
    local src = {rx, ry, rz}
    local nx = src[map.x.src] * map.x.sign
    local ny = src[map.y.src] * map.y.sign
    local nz = src[map.z.src] * map.z.sign
    if CFG.posInvert.x then nx = -nx end
    if CFG.posInvert.y then ny = -ny end
    if CFG.posInvert.z then nz = -nz end
    return vec3(nx, ny, nz)
end

-- ============================================================
-- Smoothing helpers
-- ============================================================

-- Normalized lerp between two quaternions, with sign correction so we always
-- take the short way round. Written out manually rather than relying on a
-- built-in slerp so there's no dependency on unverified quat methods.
local function nlerpQuat(a, b, t)
    local bx, by, bz, bw = b.x, b.y, b.z, b.w
    local dot = a.x * bx + a.y * by + a.z * bz + a.w * bw
    if dot < 0 then
        bx, by, bz, bw = -bx, -by, -bz, -bw
    end
    local x = a.x + (bx - a.x) * t
    local y = a.y + (by - a.y) * t
    local z = a.z + (bz - a.z) * t
    local w = a.w + (bw - a.w) * t
    local len = math.sqrt(x*x + y*y + z*z + w*w)
    if len < 1e-8 then return b end
    return quat(x/len, y/len, z/len, w/len)
end

-- Frame-rate independent smoothing factor.
local function smoothAlpha(dt)
    local s = clamp(CFG.smoothing, 0, 0.98)
    if s <= 0 then return 1 end
    -- higher smoothing -> slower approach, but always converges
    local rate = (1 - s) * 60
    return 1 - math.exp(-rate * dt)
end

-- ============================================================
-- Rotation / position math
-- ============================================================

local function computeRelRot()
    return zeroRot * phoneRot
end

-- Unclamped on purpose: if ARCore drifts, you just hit recentre.
local function computePosOffset()
    return phonePos - zeroPos
end

-- ============================================================
-- ZOOM LOD COMPENSATION
--
-- Why zooming past ~4x tanks the framerate:
--
-- Torque picks a mesh LOD from an object's projected PIXEL size, and
-- $pref::TS::detailAdjust is a straight multiplier on that estimate. Pixel
-- size is inversely proportional to tan(fov/2), so halving the FOV doubles
-- the estimate — which is arithmetically identical to doubling detailAdjust.
--
-- Zooming Nx is therefore equivalent to multiplying your Mesh Quality setting
-- by N. On High (detailAdjust 1.5), 4x zoom behaves like 6.0 and 8x like 12.0,
-- against an Ultra preset of just 2.0. That is why 1-3x is fine and it falls
-- off a cliff after 4x: you are running several times past the highest quality
-- level the game ships. Terrain behaves the same way through
-- $pref::Terrain::lodScale, except lower means more detail, so it gets divided.
--
-- The compensation divides detailAdjust by zoom^strength (and multiplies the
-- terrain scale by it), pushing the LOD selection back towards where it sits
-- at 1x. strength 1.0 makes the cost flat across the whole zoom range but
-- distant objects keep their low-detail meshes while filling the frame;
-- 0 disables it. ~0.7 keeps most of the detail you actually zoomed in to see
-- while removing most of the cost.
--
-- Changing prefs at runtime and restoring them afterwards is exactly what the
-- game's own screenshot.lua and photo mode do, so this is a sanctioned lever
-- rather than a hack.
-- ============================================================

local lodBase = nil          -- the user's own values, captured before we touch them
local lodAppliedZoom = nil   -- last zoom actually pushed, so we do not write every frame

-- CRASH RECOVERY: these prefs persist to the user's settings, so if the game
-- died while the camera was enabled the old code would have left someone's
-- Mesh Quality permanently reduced with no clue why. The captured values are
-- therefore mirrored to disk the moment we take them, and reclaimed on the
-- next load. Matters much more for other people than it does here.
local LOD_RECOVERY_PATH = "settings/phoneCamLodRecovery.json"

local function lodWriteRecovery(base)
    pcall(jsonWriteFile, LOD_RECOVERY_PATH, base or {}, true)
end

local function lodCapture()
    if lodBase then return end
    local okD, da = pcall(function() return tonumber(VariableRegistry.get("$pref::TS::detailAdjust")) end)
    local okT, tl = pcall(function() return tonumber(VariableRegistry.get("$pref::Terrain::lodScale")) end)
    lodBase = {
        detailAdjust    = (okD and da) or 1.0,
        terrainLodScale = (okT and tl) or 1.0,
    }
    lodWriteRecovery(lodBase)
end

local function lodRestore()
    if not lodBase then return end
    pcall(VariableRegistry.set, "$pref::TS::detailAdjust", lodBase.detailAdjust)
    pcall(VariableRegistry.set, "$pref::Terrain::lodScale", lodBase.terrainLodScale)
    lodBase = nil
    lodAppliedZoom = nil
    lodWriteRecovery(nil)
end

--- Puts back anything a previous session died holding.
local function lodRecoverFromCrash()
    local ok, data = pcall(jsonReadFile, LOD_RECOVERY_PATH)
    if not ok or type(data) ~= "table" then return end
    if type(data.detailAdjust) ~= "number" or type(data.terrainLodScale) ~= "number" then
        return
    end
    pcall(VariableRegistry.set, "$pref::TS::detailAdjust", data.detailAdjust)
    pcall(VariableRegistry.set, "$pref::Terrain::lodScale", data.terrainLodScale)
    lodWriteRecovery(nil)
    print("[PhoneCam] Restored graphics detail settings left over from a previous session")
end

local function lodUpdate()
    if not isEnabled or CFG.zoomLodComp <= 0 then
        lodRestore()
        return
    end

    lodCapture()

    -- Zooming OUT costs nothing, and raising detail there would be a pure
    -- loss, so only ever compensate downwards.
    local z = zoomFactor
    if z < 1 then z = 1 end

    -- Quantise: writing a pref every frame is wasteful and can churn the
    -- engine's settings callbacks.
    local qz = math.floor(z * 10 + 0.5) / 10
    if lodAppliedZoom == qz then return end
    lodAppliedZoom = qz

    local f = qz ^ CFG.zoomLodComp
    pcall(VariableRegistry.set, "$pref::TS::detailAdjust",
          clamp(lodBase.detailAdjust / f, 0.05, 20))
    pcall(VariableRegistry.set, "$pref::Terrain::lodScale",
          clamp(lodBase.terrainLodScale * f, 0.001, 4))
end

-- ============================================================
-- HANDHELD SHAKE
--
-- The camera is ALREADY shaken by bumps: relative.lua builds it from live
-- softbody node positions, so suspension travel, body roll and impacts all
-- come through. The problem is that it comes through rigidly, like a GoPro
-- zip-tied to the roll cage.
--
-- What makes footage read as handheld is the operator's arms absorbing the
-- sharp edge of a jolt and handing it back slightly late.
--
-- NOT A SPRING. The first attempt modelled this as a mass on a spring-damper
-- (x'' = -kx - cx' - a). That was wrong in kind, not merely mistuned: a spring
-- STORES energy and gives it back, which is the definition of an oscillator.
-- Every bump therefore rang at the spring's natural frequency and the result
-- felt exactly like what it was — a phone bolted to a spring bolted to the
-- car. Raising the damping only shortens the ring; it cannot remove it,
-- because the stored energy has to go somewhere.
--
-- Arms do not do that. They have no stored energy to return: they simply fail
-- to keep up, then catch up. So the model is now a target-and-chase with no
-- velocity state at all:
--
--     target = -a_local * gain     (where the hands want to be)
--     pos   += (target - pos) * k  (first-order lag, arms catching up)
--
-- Two cascaded first-order lags (the acceleration low-pass, then this) are
-- mathematically incapable of overshooting, so it can never bounce. A bump
-- produces one smooth excursion that decays as the acceleration decays, and
-- steady cornering holds a steady lean.
--
-- The rotation kick is derived from the same displacement rather than
-- integrated separately, so wrist and arm stay coherent.
--
-- WHERE THE ACCELERATION COMES FROM — this is the part that matters. The first
-- version differentiated the camera's node position TWICE. Double
-- differentiation is a +40dB/decade high-pass, multiplying the signal by
-- 1/dt^2 (~5600 at 75Hz), so the result was dominated by high-frequency
-- softbody node jitter rather than by actual bumps. Worse, the low-pass that
-- was supposed to clean it up sat at ~4Hz, right on top of the spring's 3.5Hz,
-- so the two resonated: instead of responding to bumps it rang continuously
-- along whichever axis was most excited, and swamped the other two. That is
-- the "jiggles back and forth, no up/down" symptom exactly.
--
-- The fix is to stop differentiating position. `data.vel` is the vehicle's
-- real physics velocity, handed to every camera mode (BeamNG's own driver.lua
-- uses it), so ONE differentiation gives acceleration with ~75x amplification
-- instead of ~5600x. Damping also went from 0.35 to 0.7, which still lets a
-- bump visibly settle but cannot sustain a ring.
--
-- ZOOM: angular wobble magnifies with zoom, and so does positional wobble
-- (a lateral shift d at subject distance D is an angle d/D, which then gets
-- magnified too). Both are therefore scaled by 1/zoom, which keeps the
-- SCREEN-SPACE amplitude constant — the same thing a stabilised long lens
-- does. Without this, 1x would look right and 8x would be unwatchable.
-- ============================================================

local shakePos  = vec3(0, 0, 0)   -- operator lag, car frame
local shakeAccel = vec3(0, 0, 0)  -- low-passed chassis acceleration, world
local shakePrevVel = nil

local SHAKE_MAX_ACCEL   = 120   -- m/s^2 clamp, survives dt spikes
local SHAKE_MAX_OFFSET  = 0.30  -- metres, hard stop on the lag
local SHAKE_ROT_GAIN    = 0.9   -- radians of body roll per metre of lateral lag
local SHAKE_GAIN        = 0.006 -- metres of lag per m/s^2, before compliance
local SHAKE_ACCEL_RATE  = 25.0  -- rad/s, low-pass on the measured acceleration
local SHAKE_FOLLOW_RATE = 7.0   -- rad/s, how fast the arms catch up

-- RATTLE: road and drivetrain vibration coming up through the operator.
-- The lag model above is mathematically smooth, which is exactly why it reads
-- as robotic — real footage always carries some texture. This is that texture,
-- and it scales with speed because road input does.
--
-- FREQUENCIES ARE CAPPED AROUND 13Hz, and that is not a stylistic choice.
-- The game renders at ~75fps, so anything approaching 37Hz is past Nyquist and
-- anything above roughly a quarter of the frame rate is too sparsely sampled
-- to look continuous. The first version ran up to 33Hz: barely two samples per
-- cycle, folding down into a visible 4-6Hz wobble — a tremor, which is exactly
-- what it looked like. Real rattle is 20-60Hz, but that simply cannot be drawn
-- at 75fps without motion blur, so the honest compromise is a lower frequency
-- at a much smaller amplitude: texture rather than shake.
local RATTLE_AMP_POS   = 0.0016 -- metres at full speed, 1.6mm
local RATTLE_AMP_ROT   = 0.0018 -- radians at full speed, ~0.10 degrees
-- Nothing at a crawl: the ramp starts here, not at zero. Manoeuvring at
-- walking pace should be dead still, because a real car simply is not
-- transmitting road texture at 10 km/h.
local RATTLE_SPEED_MIN = 5.0    -- m/s (18 km/h) before any rattle at all
local RATTLE_SPEED_REF = 25.0   -- m/s (90 km/h) for full strength
local RATTLE_MAX       = 1.6    -- keeps growing past the reference, but capped
local rattleTime = 0

--- Three detuned sines per axis. A single sine is instantly recognisable as
--- one; three with non-harmonic ratios never line up, so the result reads as
--- vibration rather than as a wave.
local function rattleWave(t, f1, f2, f3, p)
    local TAU = 6.2831853
    return math.sin((t * f1 + p) * TAU) * 0.50
         + math.sin((t * f2 + p * 1.7) * TAU) * 0.32
         + math.sin((t * f3 + p * 2.3) * TAU) * 0.18
end

local function shakeReset()
    shakePos = vec3(0, 0, 0)
    shakeAccel = vec3(0, 0, 0)
    shakePrevVel = nil
end

--- Returns (car-frame position offset, camera-local rotation quat).
--- `carVel` is data.vel: the vehicle's physics velocity, world frame.
local function shakeUpdate(carVel, baseRot, dt)
    if dt == nil or dt <= 0 or CFG.shakeCompliance <= 0 or carVel == nil then
        shakeReset()
        return vec3(0, 0, 0), quat(0, 0, 0, 1)
    end
    -- A loading hitch or alt-tab hands us a huge dt, which would otherwise
    -- turn into an enormous fake acceleration and fling the camera.
    if dt > 0.05 then dt = 0.05 end

    -- ONE differentiation of a real physics velocity. See the header note on
    -- why differentiating node positions twice did not work.
    if shakePrevVel then
        local a = (carVel - shakePrevVel) * (1 / dt)
        local m = a:length()
        if m > SHAKE_MAX_ACCEL then a = a * (SHAKE_MAX_ACCEL / m) end
        shakeAccel = shakeAccel + (a - shakeAccel) * (1 - math.exp(-SHAKE_ACCEL_RATE * dt))
    end
    shakePrevVel = vec3(carVel.x, carVel.y, carVel.z)

    local aLocal = baseRot:inversed() * shakeAccel

    -- Where the operator's hands want to sit: displaced opposite the current
    -- acceleration, in proportion to it. Steady cornering therefore holds a
    -- steady lean, and a bump makes one excursion that decays as the
    -- acceleration does.
    local target = aLocal * (-CFG.shakeCompliance * SHAKE_GAIN)
    local tm = target:length()
    if tm > SHAKE_MAX_OFFSET then
        target = target * (SHAKE_MAX_OFFSET / tm)
    end

    -- Chase that target with a first-order lag. No velocity state, no stored
    -- energy, so there is nothing that can overshoot and swing back.
    shakePos = shakePos + (target - shakePos) * (1 - math.exp(-SHAKE_FOLLOW_RATE * dt))

    local zScale = 1 / math.max(zoomFactor, 1)
    local total = shakePos * zScale

    -- ---- rattle -------------------------------------------------------
    -- Independent noise, deliberately NOT proportional to the translation, so
    -- it adds no fixed virtual pivot the way the old pitch/yaw coupling did.
    -- That is why rattle may safely touch all three rotation axes.
    rattleTime = rattleTime + dt
    local rattlePitch, rattleYaw, rattleRoll = 0, 0, 0

    local sf = (carVel:length() - RATTLE_SPEED_MIN)
             / (RATTLE_SPEED_REF - RATTLE_SPEED_MIN)
    if sf < 0 then sf = 0 end
    if sf > RATTLE_MAX then sf = RATTLE_MAX end
    if sf > 0.001 then
        local t = rattleTime
        local ap = RATTLE_AMP_POS * sf * zScale
        local ar = RATTLE_AMP_ROT * sf * zScale
        total = total + vec3(
            rattleWave(t, 5.3, 8.9, 12.1, 0.13) * ap,
            rattleWave(t, 6.1, 9.7, 13.3, 0.47) * ap,
            rattleWave(t, 4.7, 7.9, 11.3, 0.71) * ap * 1.4  -- vertical dominates
        )
        rattlePitch = rattleWave(t, 5.9, 9.1, 12.7, 0.29) * ar
        rattleYaw   = rattleWave(t, 5.1, 8.3, 11.9, 0.83) * ar * 0.7
        rattleRoll  = rattleWave(t, 6.7, 10.3, 13.1, 0.61) * ar * 0.7
    end

    -- ROLL ONLY, and only from lateral lag.
    --
    -- Pitch and yaw used to be derived from the lag as well. That was wrong:
    -- when a rotation is proportional to a translation, theta = g * d, the
    -- pair has an instantaneous centre of rotation 1/g metres from the
    -- camera. At the old gain that put the pivot about 0.8 m in front of the
    -- lens, so the view swung around a point out in space instead of around
    -- itself — and vertical lag in particular came out as an odd tilt rather
    -- than the clean rise and fall it should be.
    --
    -- Roll is the one rotation immune to this, because it turns about the
    -- optical axis and so never displaces the image centre. Vertical lag is
    -- now pure translation, which is also what a real operator does: the
    -- wrist keeps the camera level while the arm takes the movement.
    local q = quatFromEuler(rattlePitch,
                            shakePos.x * zScale * SHAKE_ROT_GAIN + rattleRoll,
                            rattleYaw)

    return total, q
end

-- ============================================================
-- MAPPING WIZARD
--
-- Controller-mapping style: the game asks for one motion at a time, watches
-- which PHONE axis actually moved, and writes the mapping from that.
--
-- Rotation and position are calibrated separately on purpose. The axis map is
-- shared by both, but position additionally passes through posInvert, and the
-- two genuinely can disagree: a handedness-flipping map (which is the normal
-- case, since ARCore is Y-up and BeamNG is Z-up) inverts position relative to
-- rotation. So the three rotation steps decide the axis map, and the three
-- position steps then decide posInvert given that map.
--
-- Target axes are BeamNG's camera-local frame: X = right, Y = forward, Z = up.
-- ============================================================

local WIZ_STEPS = {
    { kind = "rot", target = "z", prompt = "TURN the phone LEFT",   hint = "like shaking your head 'no'" },
    { kind = "rot", target = "x", prompt = "TILT the phone NOSE UP", hint = "top edge tips away from you" },
    { kind = "rot", target = "y", prompt = "ROLL the phone RIGHT",  hint = "right edge dips downwards" },
    { kind = "pos", target = "z", prompt = "MOVE the phone UP",     hint = "straight up, about 30 cm" },
    { kind = "pos", target = "x", prompt = "MOVE the phone RIGHT",  hint = "sideways, about 30 cm" },
    { kind = "pos", target = "y", prompt = "MOVE the phone FORWARD", hint = "away from you, about 30 cm" },
}

local WIZ_ROT_THRESHOLD = 0.40   -- rad, ~23 degrees
local WIZ_POS_THRESHOLD = 0.15   -- metres
local WIZ_DOMINANCE     = 1.6    -- winning axis must beat the runner-up by this
local WIZ_SETTLE_TIME   = 1.5    -- seconds to reposition between steps

local wiz = {
    active = false,
    step = 0,
    phase = "idle",   -- "armed" | "settle" | "done"
    settleTimer = 0,
    baseQuat = nil,
    basePos = nil,
    rotResult = {},
    posResult = {},
    detected = "",
    err = nil,
}

local function buildWizardState()
    local stepDef = WIZ_STEPS[wiz.step]
    return {
        active = wiz.active,
        step = wiz.step,
        total = #WIZ_STEPS,
        phase = wiz.phase,
        prompt = stepDef and stepDef.prompt or "",
        hint = stepDef and stepDef.hint or "",
        kind = stepDef and stepDef.kind or "",
        detected = wiz.detected,
        err = wiz.err,
    }
end

local function buildState()
    return {
        enabled = isEnabled,
        valid = isMapValid(axisMap),
        tracking = tracking,
        packets = packetsReceived,
        raw = { x = phoneRot.x, y = phoneRot.y, z = phoneRot.z, w = phoneRot.w },
        pos = { x = phonePos.x, y = phonePos.y, z = phonePos.z },
        posInvert = { x = CFG.posInvert.x, y = CFG.posInvert.y, z = CFG.posInvert.z },
        smoothing = CFG.smoothing,
        zoomFactor = zoomFactor,
        zoomMin = CFG.zoomMin,
        zoomMax = CFG.zoomMax,
        zoomLodComp = CFG.zoomLodComp,
        shakeCompliance = CFG.shakeCompliance,
        port = PORT,
        wizard = buildWizardState(),
        map = {
            x = { srcName = axisNames[axisMap.x.src], sign = axisMap.x.sign },
            y = { srcName = axisNames[axisMap.y.src], sign = axisMap.y.sign },
            z = { srcName = axisNames[axisMap.z.src], sign = axisMap.z.sign },
        },
    }
end

local function pushState()
    guihooks.trigger('PhoneCamState', buildState())
end

local function saveCalibration()
    local ok, err = pcall(function()
        jsonWriteFile(CONFIG_PATH, {
            version = CONFIG_VERSION,
            axisMap = axisMap,
            posInvert = CFG.posInvert,
            smoothing = CFG.smoothing,
            zoomLodComp = CFG.zoomLodComp,
            shakeCompliance = CFG.shakeCompliance,
            port = PORT,
        }, true)
    end)
    if ok then
        guihooks.message("Phone Camera: calibration saved", 1.5, "info")
    else
        log('E', 'phoneCam', 'Failed to save calibration: ' .. tostring(err))
    end
    pushState()
end

local function loadCalibration()
    local ok, data = pcall(jsonReadFile, CONFIG_PATH)
    if ok and data then
        -- Pre-v2 files were written before the calibrated mapping became the
        -- built-in default. Ignore their axis/invert values so everyone starts
        -- from the known-good setup; the rest is still safe to restore.
        local isCurrent = (tonumber(data.version) or 1) >= CONFIG_VERSION

        if isCurrent and data.axisMap and isMapValid(data.axisMap) then
            axisMap = data.axisMap
        end
        if isCurrent and type(data.posInvert) == "table" then
            CFG.posInvert.x = data.posInvert.x and true or false
            CFG.posInvert.y = data.posInvert.y and true or false
            CFG.posInvert.z = data.posInvert.z and true or false
        end
        -- These are fixed values now, only switched on and off, so an older
        -- file's numbers (smoothing 0.75, for one) must not come back and
        -- override the new defaults.
        if isCurrent and type(data.smoothing) == "number" then
            CFG.smoothing = clamp(data.smoothing, 0, 0.98)
        end
        if isCurrent and type(data.zoomLodComp) == "number" then
            CFG.zoomLodComp = clamp(data.zoomLodComp, 0, 1)
        end
        if isCurrent and type(data.shakeCompliance) == "number" then
            CFG.shakeCompliance = clamp(data.shakeCompliance, 0, 4)
        end
        -- Not version-gated: the port is a connectivity setting, not a tuning
        -- value, so a user who had to change it keeps it across updates.
        if type(data.port) == "number" then
            PORT = math.floor(clamp(data.port, 1024, 65535))
        end
        print("[PhoneCam] Loaded saved calibration (v" ..
              tostring(data.version or 1) .. ")")
    end
    pushState()
end

-- ============================================================
-- Wizard driving
-- ============================================================

local function wizArm()
    wiz.baseQuat = quat(rawQuat.x, rawQuat.y, rawQuat.z, rawQuat.w)
    wiz.basePos  = vec3(rawPos.x, rawPos.y, rawPos.z)
    wiz.phase = "armed"
end

local function wizardStart()
    wiz.active = true
    wiz.step = 1
    wiz.rotResult = {}
    wiz.posResult = {}
    wiz.detected = ""
    wiz.err = nil
    wizArm()
    pushState()
end

local function wizardCancel()
    wiz.active = false
    wiz.phase = "idle"
    wiz.step = 0
    pushState()
end

local function wizardApply()
    -- The three rotation steps define the axis map.
    local newMap = {}
    for _, k in ipairs({"x", "y", "z"}) do
        local r = wiz.rotResult[k]
        if not r then
            wiz.err = "Calibration incomplete - run it again"
            wiz.active = false
            wiz.phase = "idle"
            pushState()
            return
        end
        newMap[k] = { src = r.src, sign = r.sign }
    end

    if not isMapValid(newMap) then
        wiz.err = "Two game axes picked the same phone axis - run it again, " ..
                  "keeping each motion to one clean direction"
        wiz.active = false
        wiz.phase = "idle"
        pushState()
        return
    end
    axisMap = newMap

    -- The three position steps then decide posInvert, given that map.
    -- remapVec3 produces raw[src] * sign, optionally negated by posInvert, and
    -- we want a +target move to come out positive.
    for _, k in ipairs({"x", "y", "z"}) do
        local p = wiz.posResult[k]
        if p then
            if p.src == axisMap[k].src then
                CFG.posInvert[k] = (p.sign * axisMap[k].sign) < 0
            else
                wiz.err = "Rotation and position disagree on " .. string.upper(k) ..
                          " - position left unchanged for that axis"
            end
        end
    end

    wiz.active = false
    wiz.phase = "done"
    saveCalibration()
    guihooks.message("Phone Camera: mapping calibrated", 2, "info")
    pushState()
end

local function wizardUpdate(dt)
    if not wiz.active then return end

    local stepDef = WIZ_STEPS[wiz.step]
    if not stepDef then return end

    if wiz.phase == "settle" then
        wiz.settleTimer = wiz.settleTimer - dt
        -- Keep the baseline glued to the phone while the user repositions, so
        -- getting back into place cannot itself trigger the next step.
        wiz.baseQuat = quat(rawQuat.x, rawQuat.y, rawQuat.z, rawQuat.w)
        wiz.basePos  = vec3(rawPos.x, rawPos.y, rawPos.z)
        if wiz.settleTimer <= 0 then
            wiz.phase = "armed"
            pushState()
        end
        return
    end

    if wiz.phase ~= "armed" then return end

    local a, b, c
    if stepDef.kind == "rot" then
        local cur = quat(rawQuat.x, rawQuat.y, rawQuat.z, rawQuat.w)
        local dq = wiz.baseQuat:inversed() * cur
        -- take the short way round so the sign is meaningful
        if dq.w < 0 then dq = quat(-dq.x, -dq.y, -dq.z, -dq.w) end
        local angle = 2 * math.acos(clamp(dq.w, -1, 1))
        if angle < WIZ_ROT_THRESHOLD then return end
        a, b, c = dq.x, dq.y, dq.z
    else
        -- position only means anything while ARCore is tracking
        if not tracking then return end
        local dx = rawPos.x - wiz.basePos.x
        local dy = rawPos.y - wiz.basePos.y
        local dz = rawPos.z - wiz.basePos.z
        if math.sqrt(dx*dx + dy*dy + dz*dz) < WIZ_POS_THRESHOLD then return end
        a, b, c = dx, dy, dz
    end

    local vals = { a, b, c }
    local best, second = 1, 2
    for i = 2, 3 do
        if math.abs(vals[i]) > math.abs(vals[best]) then best = i end
    end
    for i = 1, 3 do
        if i ~= best and (second == best or math.abs(vals[i]) > math.abs(vals[second])) then
            second = i
        end
    end

    -- Ambiguous: the motion was diagonal. Say nothing and keep watching rather
    -- than recording a coin-flip.
    if math.abs(vals[best]) < math.abs(vals[second]) * WIZ_DOMINANCE then return end

    local src = best
    local sign = (vals[best] >= 0) and 1 or -1

    if stepDef.kind == "rot" then
        wiz.rotResult[stepDef.target] = { src = src, sign = sign }
    else
        wiz.posResult[stepDef.target] = { src = src, sign = sign }
    end
    wiz.detected = axisNames[src] .. (sign > 0 and " +" or " -")

    wiz.step = wiz.step + 1
    if wiz.step > #WIZ_STEPS then
        wizardApply()
    else
        wiz.phase = "settle"
        wiz.settleTimer = WIZ_SETTLE_TIME
        pushState()
    end
end

-- ============================================================
-- Packet parsing
-- ============================================================

local function parsePacket(rawStr)
    if not rawStr or #rawStr == 0 then return nil end

    packetsReceived = packetsReceived + 1
    if not loggedFirstPacket then
        loggedFirstPacket = true
        print("[PhoneCam] First UDP packet ever received! Content: " .. tostring(rawStr))
    end

    if rawStr:sub(1, 1) ~= "{" then
        return nil
    end

    local ok, data = pcall(jsonDecode, rawStr)
    if ok and data then
        local result = {}

        if data.sensordata and data.sensordata.quaternion then
            local q = data.sensordata.quaternion
            result.rawQuat = { x = q.x or 0, y = q.y or 0, z = q.z or 0, w = q.w or 1 }
            result.rot = remapQuat(q.x or 0, q.y or 0, q.z or 0, q.w or 1, axisMap)
        end

        if data.sensordata and data.sensordata.position then
            local p = data.sensordata.position
            result.rawPos = { x = p.x or 0, y = p.y or 0, z = p.z or 0 }
            result.pos = remapVec3(p.x or 0, p.y or 0, p.z or 0, axisMap)
        end

        if data.sensordata and data.sensordata.trackingState then
            result.tracking = (data.sensordata.trackingState == "TRACKING")
        end

        if data.zoomRate ~= nil then
            result.zoomRate = tonumber(data.zoomRate)
        end

        if data.zoomPreset ~= nil then
            result.zoomPreset = tonumber(data.zoomPreset)
        end

        if data.recenter then
            result.recenter = true
        end

        if result.rot or result.pos or result.zoomRate or result.zoomPreset or result.recenter then
            return result
        end
    end

    return nil
end

-- ============================================================
-- HUD-callable API
-- ============================================================

local function cycleSource(k)
    if not axisMap[k] then return end
    axisMap[k].src = (axisMap[k].src % 3) + 1
    pushState()
end

local function flipSign(k)
    if not axisMap[k] then return end
    axisMap[k].sign = -axisMap[k].sign
    pushState()
end

local function flipPosInvert(k)
    if CFG.posInvert[k] == nil then return end
    CFG.posInvert[k] = not CFG.posInvert[k]
    pushState()
end

local function setSmoothing(v)
    v = tonumber(v)
    if v then CFG.smoothing = clamp(v, 0, 0.98); pushState() end
end

local function setZoomLodComp(v)
    v = tonumber(v)
    if v then
        CFG.zoomLodComp = clamp(v, 0, 1)
        -- force the next lodUpdate to rewrite rather than skip on the
        -- quantised-zoom check
        lodAppliedZoom = nil
        pushState()
    end
end

--- (Re)binds the listening socket. Safe to call at any time.
local function openSocket()
    if udpSocket then
        pcall(function() udpSocket:close() end)
        udpSocket = nil
    end
    local s = socket.udp()
    if not s then
        print("[PhoneCam] ERROR: could not create UDP socket")
        return false
    end
    local okBind, bindErr = s:setsockname("*", PORT)
    if not okBind then
        print("[PhoneCam] ERROR: could not bind UDP port " .. PORT ..
              " - another program may be using it. Error: " .. tostring(bindErr))
        pcall(function() s:close() end)
        return false
    end
    s:settimeout(0)
    udpSocket = s
    print("[PhoneCam] Listening on UDP port " .. PORT)
    return true
end

--- Changes the listening port and rebinds. The phone must be set to match.
local function setPort(p)
    p = tonumber(p)
    if not p then return end
    p = math.floor(clamp(p, 1024, 65535))
    if p == PORT then return end

    PORT = p
    -- the old phone address belongs to the old socket
    phoneIp = nil
    phonePort = nil
    packetsReceived = 0

    if openSocket() then
        guihooks.message("Phone Camera: listening on UDP " .. PORT, 3, "info")
    else
        guihooks.message("Phone Camera: could not open UDP " .. PORT ..
                         " - it may be in use", 5, "error")
    end
    saveCalibration()
    pushState()
end

local function setShakeCompliance(v)
    v = tonumber(v)
    if v then
        -- ceiling is 4, not 1: the useful range turned out to be well above
        -- the original 0..1 guess
        CFG.shakeCompliance = clamp(v, 0, 4)
        shakeReset()
        pushState()
    end
end

local function resetCalibration()
    axisMap = defaultAxisMap()
    CFG.posInvert = { x = true, y = true, z = true }
    guihooks.message("Phone Camera: axis defaults restored", 1.5, "info")
    pushState()
end

--- One-shot state dump for troubleshooting. Run in the GE console:
---   extensions.auto_phoneCam.debugDump()
local function debugDump()
    local relRot = computeRelRot()
    local off = computePosOffset()
    local camName = "?"
    pcall(function() camName = tostring(core_camera.getActiveCamName()) end)

    print("=== PhoneCam debug ===")
    print("  enabled      : " .. tostring(isEnabled) ..
          "   <-- camera only moves when this is true")
    print("  active camera: " .. camName ..
          "   <-- must be 'relative'")
    local patched = {}
    for name, _ in pairs(patchedModes) do table.insert(patched, name) end
    print("  patched modes: " .. (#patched > 0 and table.concat(patched, ", ") or "NONE") ..
          "   <-- active camera must be one of these")
    print("  packets recvd: " .. tostring(packetsReceived))
    print("  tracking     : " .. tostring(tracking))
    print("  phone quat   : " .. string.format("%.3f %.3f %.3f %.3f",
          phoneRot.x, phoneRot.y, phoneRot.z, phoneRot.w))
    print("  rel rotation : " .. string.format("%.3f %.3f %.3f %.3f",
          relRot.x, relRot.y, relRot.z, relRot.w) ..
          "   <-- identity (0 0 0 1) means no rotation is being applied")
    print("  pos offset   : " .. string.format("%.3f %.3f %.3f", off.x, off.y, off.z))
    print("  smoothing    : " .. tostring(CFG.smoothing))
    print("  zoom         : " .. tostring(zoomFactor))
    print("  phone addr   : " .. tostring(phoneIp) .. ":" .. tostring(phonePort))
    print("======================")
end

local function toggle()
    isEnabled = not isEnabled
    -- The patch only runs while enabled, so the position history is stale on
    -- re-enable and would differentiate into a huge fake acceleration.
    shakeReset()
    if not isEnabled then
        baseFov = nil
    end
    guihooks.message(isEnabled and "Phone Camera: ENABLED" or "Phone Camera: DISABLED", 2, "info")
    pushState()
end

local function recenter()
    -- snap the smoothed values to the newest data so recentre is exact
    phoneRot = targetRot
    phonePos = targetPos
    zeroRot = quat(phoneRot.x, phoneRot.y, phoneRot.z, phoneRot.w):inversed()
    zeroPos = vec3(phonePos.x, phonePos.y, phonePos.z)
    guihooks.message("Phone Camera: RECENTERED", 1.5, "info")
    pushState()
end

-- ============================================================
-- Extension lifecycle
-- ============================================================

--- The actual camera override, shared by every mode we patch.
local function applyPhoneCam(data)
    if not (isEnabled and data.res and data.res.rot) then return end

    local baseRot = quat(data.res.rot.x, data.res.rot.y,
                         data.res.rot.z, data.res.rot.w)

    local relRot = computeRelRot()
    local posOffset = computePosOffset()

    local shakeOffset, shakeRot = shakeUpdate(data.vel, baseRot, data.dt)

    -- World composition for the phone's aim; the shake is a wrist wobble, so
    -- it composes on the RIGHT, in the camera's own frame.
    data.res.rot = relRot * baseRot * shakeRot

    -- Position offsets live in the camera's own frame.
    if data.res.pos then
        data.res.pos = data.res.pos + (baseRot * (posOffset + shakeOffset))
    end

    -- Zoom as a real multiplier: 1x = the mode's own FOV, 2x = half the FOV
    -- (tele), 0.7x = wider.
    if CFG.zoomEnabled and data.res.fov then
        if not baseFov then
            baseFov = data.res.fov
        end
        data.res.fov = clamp(baseFov / zoomFactor, 5, 140)
    end
end

--- Patches one camera mode's update(). Every mode shares a single metatable
--- across all its instances, so patching it here covers cameras that already
--- exist as well as ones created later.
local function patchCameraMode(modeName)
    if patchedModes[modeName] then return end

    local ok, factory = pcall(require, 'core/cameraModes/' .. modeName)
    if not (ok and factory) then
        print("[PhoneCam] Could not require core/cameraModes/" .. modeName)
        return
    end

    local okDummy, dummy = pcall(factory)
    if not (okDummy and dummy) then
        print("[PhoneCam] Could not create dummy " .. modeName .. " instance")
        return
    end

    local C = getmetatable(dummy)
    if not (C and C.update) then
        print("[PhoneCam] " .. modeName .. " has no update() to patch")
        return
    end

    local original = C.update
    C.update = function(self, data)
        local ok2 = original(self, data)
        if ok2 then applyPhoneCam(data) end
        return ok2
    end
    patchedModes[modeName] = { C = C, original = original }
    print("[PhoneCam] Patched '" .. modeName .. "' camera mode successfully")
end

local function onExtensionLoaded()
    lodRecoverFromCrash()
    loadCalibration()

    openSocket()

    -- 'relative' is the in-car handheld view; 'free' is the Shift+C fly
    -- camera, which lets you shoot the car from outside it.
    patchCameraMode('relative')
    patchCameraMode('free')
end

local pushTimer = 0
local PUSH_INTERVAL = 0.1

local function onUpdate(dt)
    if udpSocket then
        -- receivefrom rather than receive: we need the sender's address so the
        -- heartbeat has somewhere to go.
        local data, fromIp, fromPort = udpSocket:receivefrom()
        while data do
            if fromIp then
                phoneIp = fromIp
                phonePort = fromPort
            end
            local parsed = parsePacket(data)
            if parsed then
                -- raw values are stored unconditionally: the wizard needs to
                -- see rotation even before tracking is established
                if parsed.rawQuat then
                    rawQuat = parsed.rawQuat
                end
                if parsed.rawPos then
                    rawPos = parsed.rawPos
                end
                if parsed.rot then
                    targetRot = parsed.rot
                end
                if parsed.tracking ~= nil then
                    tracking = parsed.tracking
                end
                if parsed.pos and tracking then
                    targetPos = parsed.pos
                end
                if parsed.zoomRate then
                    zoomRate = clamp(parsed.zoomRate, -1, 1)
                end
                if parsed.zoomPreset then
                    zoomFactor = clamp(parsed.zoomPreset, CFG.zoomMin, CFG.zoomMax)
                    zoomRate = 0
                end
                if parsed.recenter then
                    pendingRecenter = true
                end
            end
            data, fromIp, fromPort = udpSocket:receivefrom()
        end

        -- answer the phone so it can show a connection state
        ackTimer = ackTimer + dt
        if ackTimer >= ACK_INTERVAL and phoneIp and phonePort then
            ackTimer = 0
            pcall(function()
                udpSocket:sendto(
                    '{"pcAck":1,"enabled":' .. tostring(isEnabled) .. '}',
                    phoneIp, phonePort)
            end)
        end
    end

    -- Interpolate toward the newest pose every frame. This is what turns
    -- 30Hz phone data into smooth motion at the game's ~75Hz render rate.
    local a = smoothAlpha(dt)
    phoneRot = nlerpQuat(phoneRot, targetRot, a)
    phonePos = phonePos + (targetPos - phonePos) * a

    if pendingRecenter then
        pendingRecenter = false
        recenter()
    end

    wizardUpdate(dt)
    lodUpdate()

    -- Camcorder-style zoom: rocker deflection is SPEED. Multiplicative so
    -- zooming feels even across the whole range.
    if math.abs(zoomRate) > 0.001 then
        zoomFactor = clamp(zoomFactor * math.exp(zoomRate * CFG.zoomRateSpeed * dt),
                           CFG.zoomMin, CFG.zoomMax)
    end

    pushTimer = pushTimer + dt
    if pushTimer >= PUSH_INTERVAL then
        pushTimer = 0
        pushState()
    end
end

local function onExtensionUnloaded()
    -- never leave the user's graphics settings altered behind us
    lodRestore()
    if udpSocket then udpSocket:close() end
    -- put every camera mode back exactly as we found it
    for name, p in pairs(patchedModes) do
        p.C.update = p.original
        patchedModes[name] = nil
    end
end

M.onExtensionLoaded = onExtensionLoaded
M.onUpdate = onUpdate
M.onExtensionUnloaded = onExtensionUnloaded
M.toggle = toggle
M.recenter = recenter
M.debugDump = debugDump

M.cycleSource = cycleSource
M.flipSign = flipSign
M.flipPosInvert = flipPosInvert
M.setSmoothing = setSmoothing
M.setZoomLodComp = setZoomLodComp
M.setPort = setPort
M.setShakeCompliance = setShakeCompliance
M.resetCalibration = resetCalibration
M.wizardStart = wizardStart
M.wizardCancel = wizardCancel
M.saveCalibration = saveCalibration
M.loadCalibration = loadCalibration
M.pushState = pushState

return M
